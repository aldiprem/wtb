// ===== WEBSITE JS - STORE FRONT =====

// Base URL dari tunnel
const BASE_URL = 'https://formerly-colors-imposed-salem.trycloudflare.com';

// State management
let cart = [];
let currentProduct = null;
let currentWebsite = null;

// ===== INITIALIZATION =====
document.addEventListener('DOMContentLoaded', function() {
    initializeCart();
    loadWebsiteData();
    setupEventListeners();
});

// ===== CART MANAGEMENT =====
function initializeCart() {
    // Load cart from localStorage
    const savedCart = localStorage.getItem('cart');
    if (savedCart) {
        try {
            cart = JSON.parse(savedCart);
            updateCartCount();
        } catch (e) {
            console.error('Error loading cart:', e);
            cart = [];
        }
    }
}

function updateCartCount() {
    const cartBadges = document.querySelectorAll('.cart-badge');
    const totalItems = cart.reduce((sum, item) => sum + item.quantity, 0);
    
    cartBadges.forEach(badge => {
        if (totalItems > 0) {
            badge.textContent = totalItems;
            badge.style.display = 'flex';
        } else {
            badge.style.display = 'none';
        }
    });
}

function saveCart() {
    localStorage.setItem('cart', JSON.stringify(cart));
    updateCartCount();
    
    // Trigger cart update event
    document.dispatchEvent(new CustomEvent('cartUpdated', { detail: cart }));
}

async function addToCart(productId, quantity = 1) {
    try {
        // Get product details
        const product = await getProduct(productId);
        
        if (!product) {
            showNotification('Produk tidak ditemukan', 'error');
            return;
        }
        
        // Check if already in cart
        const existingItem = cart.find(item => item.id === productId);
        
        if (existingItem) {
            existingItem.quantity += quantity;
        } else {
            cart.push({
                id: product.id,
                name: product.name,
                price: product.price,
                image: product.image_url,
                quantity: quantity,
                max_stock: product.stock
            });
        }
        
        saveCart();
        showNotification('Produk ditambahkan ke keranjang!', 'success');
        
        // Animate cart icon
        animateCartIcon();
        
    } catch (error) {
        console.error('Error adding to cart:', error);
        showNotification('Gagal menambahkan ke keranjang', 'error');
    }
}

function removeFromCart(productId) {
    cart = cart.filter(item => item.id !== productId);
    saveCart();
    renderCart();
    showNotification('Produk dihapus dari keranjang', 'info');
}

function updateCartItemQuantity(productId, quantity) {
    const item = cart.find(item => item.id === productId);
    if (item) {
        if (quantity <= 0) {
            removeFromCart(productId);
        } else if (quantity <= item.max_stock) {
            item.quantity = quantity;
            saveCart();
            renderCart();
        } else {
            showNotification('Melebihi stok tersedia', 'warning');
        }
    }
}

function clearCart() {
    cart = [];
    saveCart();
    renderCart();
    showNotification('Keranjang dikosongkan', 'info');
}

function getCartTotal() {
    return cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
}

function animateCartIcon() {
    const cartIcon = document.querySelector('.cart-icon');
    if (cartIcon) {
        cartIcon.classList.add('animate');
        setTimeout(() => {
            cartIcon.classList.remove('animate');
        }, 500);
    }
}

// ===== PRODUCT FUNCTIONS =====
async function getProduct(productId) {
    if (!currentWebsite) return null;
    
    try {
        const response = await fetch(`${BASE_URL}/api/store/${currentWebsite.endpoint}/products/${productId}`);
        if (response.ok) {
            return await response.json();
        }
    } catch (error) {
        console.error('Error fetching product:', error);
    }
    return null;
}

async function loadProducts(categoryId = null, search = null) {
    showLoading();
    
    try {
        let url = `${BASE_URL}/api/store/${currentWebsite.endpoint}/products`;
        const params = new URLSearchParams();
        
        if (categoryId) params.append('category', categoryId);
        if (search) params.append('search', search);
        
        if (params.toString()) {
            url += '?' + params.toString();
        }
        
        const response = await fetch(url);
        const products = await response.json();
        
        renderProducts(products);
    } catch (error) {
        console.error('Error loading products:', error);
        showNotification('Gagal memuat produk', 'error');
    } finally {
        hideLoading();
    }
}

function renderProducts(products) {
    const container = document.querySelector('.products-grid');
    if (!container) return;
    
    if (!products || products.length === 0) {
        container.innerHTML = `
            <div class="col-span-full text-center py-12">
                <i class="fas fa-box-open text-5xl text-gray-300 mb-4"></i>
                <p class="text-gray-500">Tidak ada produk</p>
            </div>
        `;
        return;
    }
    
    container.innerHTML = products.map(product => `
        <div class="product-card" data-id="${product.id}">
            ${product.is_featured ? '<span class="product-badge featured">Featured</span>' : ''}
            ${product.compare_price ? '<span class="product-badge">Sale</span>' : ''}
            
            <img src="${product.image_url || 'https://via.placeholder.com/300'}" 
                 alt="${escapeHtml(product.name)}" 
                 class="product-image"
                 onerror="this.src='https://via.placeholder.com/300'">
            
            <div class="product-info">
                <div class="product-category">${escapeHtml(product.category_name || 'Produk')}</div>
                <h3 class="product-name">${escapeHtml(product.name)}</h3>
                
                <div class="product-price">
                    <span class="current-price">${formatCurrency(product.price)}</span>
                    ${product.compare_price ? 
                        `<span class="old-price">${formatCurrency(product.compare_price)}</span>` : 
                        ''}
                </div>
                
                <div class="product-actions">
                    <button onclick="addToCart(${product.id}, 1)" 
                            class="btn-add-to-cart"
                            ${product.stock <= 0 ? 'disabled' : ''}>
                        <i class="fas fa-shopping-cart"></i>
                        ${product.stock > 0 ? 'Tambah ke Cart' : 'Stok Habis'}
                    </button>
                    <button onclick="toggleWishlist(${product.id})" class="btn-wishlist">
                        <i class="far fa-heart"></i>
                    </button>
                </div>
            </div>
        </div>
    `).join('');
}

// ===== CART RENDERING =====
function renderCart() {
    const cartContainer = document.querySelector('.cart-items');
    if (!cartContainer) return;
    
    if (cart.length === 0) {
        cartContainer.innerHTML = `
            <div class="empty-cart text-center py-12">
                <i class="fas fa-shopping-cart text-5xl text-gray-300 mb-4"></i>
                <p class="text-gray-500">Keranjang belanja kosong</p>
                <a href="/store/${currentWebsite.endpoint}/products" class="btn btn-primary mt-4">
                    Mulai Belanja
                </a>
            </div>
        `;
        
        // Update summary
        document.querySelector('.cart-summary').innerHTML = `
            <h3 class="text-lg font-semibold mb-4">Ringkasan Belanja</h3>
            <div class="summary-item">
                <span>Total</span>
                <span class="font-bold">${formatCurrency(0)}</span>
            </div>
            <button class="btn btn-primary w-full mt-4" disabled>
                Checkout
            </button>
        `;
        
        return;
    }
    
    cartContainer.innerHTML = cart.map(item => `
        <div class="cart-item" data-id="${item.id}">
            <img src="${item.image || 'https://via.placeholder.com/100'}" 
                 alt="${escapeHtml(item.name)}" 
                 class="cart-item-image">
            
            <div class="cart-item-details">
                <h3>${escapeHtml(item.name)}</h3>
                <div class="cart-item-price">${formatCurrency(item.price)}</div>
                
                <div class="cart-item-quantity">
                    <button onclick="updateCartItemQuantity(${item.id}, ${item.quantity - 1})" 
                            class="quantity-btn">-</button>
                    <span class="quantity">${item.quantity}</span>
                    <button onclick="updateCartItemQuantity(${item.id}, ${item.quantity + 1})" 
                            class="quantity-btn"
                            ${item.quantity >= item.max_stock ? 'disabled' : ''}>+</button>
                </div>
            </div>
            
            <div class="cart-item-total">
                <div class="font-bold">${formatCurrency(item.price * item.quantity)}</div>
                <button onclick="removeFromCart(${item.id})" class="cart-item-remove">
                    <i class="fas fa-trash"></i>
                </button>
            </div>
        </div>
    `).join('');
    
    // Update summary
    const subtotal = getCartTotal();
    const summary = document.querySelector('.cart-summary');
    if (summary) {
        summary.innerHTML = `
            <h3 class="text-lg font-semibold mb-4">Ringkasan Belanja</h3>
            <div class="summary-item">
                <span>Subtotal (${cart.length} item)</span>
                <span>${formatCurrency(subtotal)}</span>
            </div>
            <div class="summary-total">
                <span>Total</span>
                <span class="font-bold text-primary">${formatCurrency(subtotal)}</span>
            </div>
            <button onclick="proceedToCheckout()" class="btn btn-primary w-full mt-4">
                Checkout (${formatCurrency(subtotal)})
            </button>
        `;
    }
}

// ===== CHECKOUT =====
async function proceedToCheckout() {
    if (cart.length === 0) {
        showNotification('Keranjang belanja kosong', 'warning');
        return;
    }
    
    window.location.href = `/store/${currentWebsite.endpoint}/checkout`;
}

async function submitCheckout(formData) {
    showLoading();
    
    try {
        const response = await fetch(`${BASE_URL}/api/store/${currentWebsite.endpoint}/checkout`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                ...formData,
                items: cart.map(item => ({
                    product_id: item.id,
                    quantity: item.quantity,
                    price: item.price
                }))
            })
        });
        
        const data = await response.json();
        
        if (data.success) {
            // Clear cart
            cart = [];
            saveCart();
            
            showNotification('Pesanan berhasil dibuat!', 'success');
            setTimeout(() => {
                window.location.href = data.redirect;
            }, 1500);
        } else {
            showNotification(data.message || 'Checkout gagal', 'error');
        }
    } catch (error) {
        console.error('Checkout error:', error);
        showNotification('Terjadi kesalahan', 'error');
    } finally {
        hideLoading();
    }
}

// ===== WISHLIST =====
function toggleWishlist(productId) {
    let wishlist = JSON.parse(localStorage.getItem('wishlist') || '[]');
    
    const index = wishlist.indexOf(productId);
    if (index === -1) {
        wishlist.push(productId);
        showNotification('Ditambahkan ke wishlist', 'success');
    } else {
        wishlist.splice(index, 1);
        showNotification('Dihapus dari wishlist', 'info');
    }
    
    localStorage.setItem('wishlist', JSON.stringify(wishlist));
}

// ===== WEBSITE DATA =====
async function loadWebsiteData() {
    // Get endpoint from URL
    const pathParts = window.location.pathname.split('/');
    const endpoint = pathParts[2]; // /store/[endpoint]/...
    
    if (!endpoint) return;
    
    try {
        const response = await fetch(`${BASE_URL}/api/website/${endpoint}`);
        if (response.ok) {
            currentWebsite = await response.json();
            applyTheme();
        }
    } catch (error) {
        console.error('Error loading website data:', error);
    }
}

function applyTheme() {
    if (!currentWebsite) return;
    
    // Apply theme color
    document.documentElement.style.setProperty('--primary', currentWebsite.theme_color);
    
    // Update meta tags
    if (currentWebsite.meta_title) {
        document.title = currentWebsite.meta_title;
    }
    
    // Update favicon
    if (currentWebsite.favicon_url) {
        let link = document.querySelector("link[rel~='icon']");
        if (!link) {
            link = document.createElement('link');
            link.rel = 'icon';
            document.head.appendChild(link);
        }
        link.href = currentWebsite.favicon_url;
    }
}

// ===== UI HELPERS =====
function showLoading() {
    let loader = document.querySelector('.store-loader');
    if (!loader) {
        loader = document.createElement('div');
        loader.className = 'store-loader';
        loader.innerHTML = '<div class="loading-spinner"></div>';
        document.body.appendChild(loader);
    }
    loader.style.display = 'flex';
}

function hideLoading() {
    const loader = document.querySelector('.store-loader');
    if (loader) {
        loader.style.display = 'none';
    }
}

function showNotification(message, type = 'info') {
    // Check if notification container exists
    let container = document.querySelector('.notification-container');
    if (!container) {
        container = document.createElement('div');
        container.className = 'notification-container';
        document.body.appendChild(container);
    }
    
    // Create notification
    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    notification.innerHTML = `
        <i class="fas fa-${type === 'success' ? 'check-circle' : 
                           type === 'error' ? 'exclamation-circle' : 
                           type === 'warning' ? 'exclamation-triangle' : 
                           'info-circle'}"></i>
        <span>${message}</span>
    `;
    
    container.appendChild(notification);
    
    // Remove after 3 seconds
    setTimeout(() => {
        notification.classList.add('fade-out');
        setTimeout(() => {
            notification.remove();
            if (container.children.length === 0) {
                container.remove();
            }
        }, 300);
    }, 3000);
}

function formatCurrency(amount) {
    return new Intl.NumberFormat('id-ID', {
        style: 'currency',
        currency: currentWebsite?.currency || 'IDR',
        minimumFractionDigits: 0
    }).format(amount);
}

function escapeHtml(unsafe) {
    if (!unsafe) return '';
    return unsafe
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");
}

// ===== EVENT LISTENERS =====
function setupEventListeners() {
    // Search form
    const searchForm = document.querySelector('.search-form');
    if (searchForm) {
        searchForm.addEventListener('submit', (e) => {
            e.preventDefault();
            const searchInput = searchForm.querySelector('.search-input');
            if (searchInput && searchInput.value) {
                window.location.href = `/store/${currentWebsite.endpoint}/products?search=${encodeURIComponent(searchInput.value)}`;
            }
        });
    }
    
    // Quantity inputs in product detail
    const quantityInput = document.querySelector('.quantity-input');
    if (quantityInput) {
        const decreaseBtn = document.querySelector('.quantity-btn.decrease');
        const increaseBtn = document.querySelector('.quantity-btn.increase');
        
        if (decreaseBtn) {
            decreaseBtn.addEventListener('click', () => {
                let val = parseInt(quantityInput.value) - 1;
                if (val < 1) val = 1;
                quantityInput.value = val;
            });
        }
        
        if (increaseBtn) {
            increaseBtn.addEventListener('click', () => {
                let val = parseInt(quantityInput.value) + 1;
                const max = parseInt(quantityInput.max);
                if (max && val > max) val = max;
                quantityInput.value = val;
            });
        }
    }
    
    // Add to cart button in product detail
    const addToCartBtn = document.querySelector('.btn-add-to-cart-detail');
    if (addToCartBtn) {
        addToCartBtn.addEventListener('click', () => {
            const productId = addToCartBtn.dataset.productId;
            const quantity = parseInt(document.querySelector('.quantity-input')?.value || 1);
            addToCart(parseInt(productId), quantity);
        });
    }
    
    // Buy now button
    const buyNowBtn = document.querySelector('.btn-buy-now');
    if (buyNowBtn) {
        buyNowBtn.addEventListener('click', async () => {
            const productId = buyNowBtn.dataset.productId;
            const quantity = parseInt(document.querySelector('.quantity-input')?.value || 1);
            
            await addToCart(parseInt(productId), quantity);
            proceedToCheckout();
        });
    }
    
    // Cart updated event
    document.addEventListener('cartUpdated', () => {
        if (window.location.pathname.includes('/cart')) {
            renderCart();
        }
    });
}

// Export functions for use in HTML
window.addToCart = addToCart;
window.removeFromCart = removeFromCart;
window.updateCartItemQuantity = updateCartItemQuantity;
window.clearCart = clearCart;
window.proceedToCheckout = proceedToCheckout;
window.submitCheckout = submitCheckout;
window.toggleWishlist = toggleWishlist;
window.formatCurrency = formatCurrency;