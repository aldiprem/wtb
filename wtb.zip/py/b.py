import os
import logging
import asyncio
import sqlite3
from datetime import datetime
from dotenv import load_dotenv
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import (
    Application,
    CommandHandler,
    CallbackQueryHandler,
    ContextTypes
)
from database import get_db

# Load environment variables
load_dotenv()

# Logging
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

# Constants
BOT_TOKEN = os.getenv('BOT_TOKEN')
ADMIN_ID = int(os.getenv('ADMIN_TELEGRAM_ID', 0))

def format_currency(amount):
    """Format angka ke Rupiah"""
    return f"Rp {amount:,.0f}".replace(',', '.')

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handler untuk /start command"""
    user = update.effective_user
    
    # Cek apakah user adalah admin
    if user.id == ADMIN_ID:
        keyboard = [
            [InlineKeyboardButton("📊 Dashboard", callback_data="admin_dashboard")],
            [InlineKeyboardButton("📦 Pesanan Baru", callback_data="admin_new_orders")],
            [InlineKeyboardButton("📦 Semua Pesanan", callback_data="admin_all_orders")],
            [InlineKeyboardButton("📦 Pesanan Selesai", callback_data="admin_completed_orders")],
            [InlineKeyboardButton("📊 Statistik", callback_data="admin_stats")]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await update.message.reply_text(
            f"👋 Halo Admin {user.full_name}!\n\n"
            "Selamat datang di panel admin TopUp Store.\n"
            "Pilih menu di bawah untuk mengelola toko:",
            reply_markup=reply_markup
        )
    else:
        await update.message.reply_text(
            "👋 Halo! Ini adalah bot resmi TopUp Store.\n\n"
            "Untuk berbelanja, silakan kunjungi website kami:\n"
            f"{os.getenv('WEBSITE_URL', 'https://website-anda.ngrok.io')}\n\n"
            "Bot ini digunakan untuk notifikasi pesanan Anda."
        )

async def admin_dashboard(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show admin dashboard"""
    query = update.callback_query
    await query.answer()
    
    if query.from_user.id != ADMIN_ID:
        await query.edit_message_text("Akses ditolak. Anda bukan admin.")
        return
    
    with get_db() as conn:
        # Hitung statistik
        total_orders = conn.execute('SELECT COUNT(*) FROM orders').fetchone()[0]
        pending_orders = conn.execute(
            "SELECT COUNT(*) FROM orders WHERE order_status = 'pending'"
        ).fetchone()[0]
        completed_orders = conn.execute(
            "SELECT COUNT(*) FROM orders WHERE order_status = 'completed'"
        ).fetchone()[0]
        total_revenue = conn.execute(
            "SELECT SUM(total_amount) FROM orders WHERE order_status = 'completed'"
        ).fetchone()[0] or 0
        total_products = conn.execute(
            'SELECT COUNT(*) FROM products WHERE is_active = 1'
        ).fetchone()[0]
        total_users = conn.execute('SELECT COUNT(*) FROM users').fetchone()[0]
    
    text = (
        f"📊 *Admin Dashboard*\n\n"
        f"📦 Total Pesanan: {total_orders}\n"
        f"⏳ Pesanan Pending: {pending_orders}\n"
        f"✅ Pesanan Selesai: {completed_orders}\n"
        f"💰 Total Revenue: {format_currency(total_revenue)}\n"
        f"🛒 Total Produk: {total_products}\n"
        f"👥 Total User: {total_users}\n\n"
        f"Pilih menu di bawah untuk detail:"
    )
    
    keyboard = [
        [InlineKeyboardButton("📦 Pesanan Baru", callback_data="admin_new_orders")],
        [InlineKeyboardButton("📦 Semua Pesanan", callback_data="admin_all_orders")],
        [InlineKeyboardButton("✅ Pesanan Selesai", callback_data="admin_completed_orders")],
        [InlineKeyboardButton("🔙 Kembali", callback_data="start")]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await query.edit_message_text(
        text,
        parse_mode='Markdown',
        reply_markup=reply_markup
    )

async def admin_new_orders(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show new orders"""
    query = update.callback_query
    await query.answer()
    
    if query.from_user.id != ADMIN_ID:
        await query.edit_message_text("Akses ditolak.")
        return
    
    with get_db() as conn:
        orders = conn.execute('''
            SELECT o.*, u.full_name, u.username 
            FROM orders o
            JOIN users u ON o.user_id = u.id
            WHERE o.order_status = 'pending' OR o.order_status = 'paid'
            ORDER BY o.created_at DESC
            LIMIT 10
        ''').fetchall()
    
    if not orders:
        await query.edit_message_text(
            "Tidak ada pesanan baru.",
            reply_markup=InlineKeyboardMarkup([[
                InlineKeyboardButton("🔙 Kembali", callback_data="admin_dashboard")
            ]])
        )
        return
    
    for order in orders:
        status_emoji = {
            'pending': '⏳',
            'paid': '💳',
            'processing': '⚙️',
            'completed': '✅',
            'cancelled': '❌'
        }.get(order['order_status'], '📦')
        
        text = (
            f"{status_emoji} *Pesanan #{order['order_number']}*\n"
            f"👤 Customer: {order['full_name']} (@{order['username']})\n"
            f"💰 Total: {format_currency(order['total_amount'])}\n"
            f"📞 WA: {order['customer_phone']}\n"
            f"📧 Email: {order['customer_email'] or '-'}\n"
            f"📅 Tanggal: {order['created_at']}\n"
            f"📊 Status: {order['order_status'].upper()}"
        )
        
        keyboard = [[
            InlineKeyboardButton(
                "✅ Proses Pesanan", 
                callback_data=f"process_order_{order['id']}"
            )
        ]]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await query.message.reply_text(
            text,
            parse_mode='Markdown',
            reply_markup=reply_markup
        )
    
    await query.message.reply_text(
        "Pilih pesanan di atas untuk diproses.",
        reply_markup=InlineKeyboardMarkup([[
            InlineKeyboardButton("🔙 Kembali ke Dashboard", callback_data="admin_dashboard")
        ]])
    )

async def admin_all_orders(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show all orders"""
    query = update.callback_query
    await query.answer()
    
    if query.from_user.id != ADMIN_ID:
        return
    
    with get_db() as conn:
        orders = conn.execute('''
            SELECT o.*, u.full_name 
            FROM orders o
            JOIN users u ON o.user_id = u.id
            ORDER BY o.created_at DESC
            LIMIT 10
        ''').fetchall()
    
    if not orders:
        await query.edit_message_text("Belum ada pesanan.")
        return
    
    for order in orders:
        status_emoji = {
            'pending': '⏳',
            'paid': '💳',
            'processing': '⚙️',
            'completed': '✅',
            'cancelled': '❌'
        }.get(order['order_status'], '📦')
        
        text = (
            f"{status_emoji} *{order['order_number']}*\n"
            f"👤 {order['full_name']}\n"
            f"💰 {format_currency(order['total_amount'])}\n"
            f"📊 {order['order_status']}\n"
            f"📅 {order['created_at'][:16]}"
        )
        
        keyboard = [[
            InlineKeyboardButton(
                "📋 Detail", 
                callback_data=f"detail_order_{order['id']}"
            )
        ]]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await query.message.reply_text(
            text,
            parse_mode='Markdown',
            reply_markup=reply_markup
        )
    
    await query.message.reply_text(
        "🔙 Kembali ke Dashboard",
        reply_markup=InlineKeyboardMarkup([[
            InlineKeyboardButton("Kembali", callback_data="admin_dashboard")
        ]])
    )

async def admin_completed_orders(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show completed orders"""
    query = update.callback_query
    await query.answer()
    
    if query.from_user.id != ADMIN_ID:
        return
    
    with get_db() as conn:
        orders = conn.execute('''
            SELECT o.*, u.full_name 
            FROM orders o
            JOIN users u ON o.user_id = u.id
            WHERE o.order_status = 'completed'
            ORDER BY o.completed_at DESC
            LIMIT 10
        ''').fetchall()
    
    if not orders:
        await query.edit_message_text("Belum ada pesanan selesai.")
        return
    
    text = "✅ *Pesanan Selesai*\n\n"
    for order in orders:
        text += (
            f"• {order['order_number']}\n"
            f"  {order['full_name']} - {format_currency(order['total_amount'])}\n"
            f"  {order['completed_at'][:16]}\n\n"
        )
    
    keyboard = [[
        InlineKeyboardButton("🔙 Kembali", callback_data="admin_dashboard")
    ]]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await query.edit_message_text(
        text,
        parse_mode='Markdown',
        reply_markup=reply_markup
    )

async def admin_stats(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show statistics"""
    query = update.callback_query
    await query.answer()
    
    if query.from_user.id != ADMIN_ID:
        return
    
    with get_db() as conn:
        # Pesanan per hari (7 hari terakhir)
        daily_orders = conn.execute('''
            SELECT DATE(created_at) as date, COUNT(*) as count, SUM(total_amount) as revenue
            FROM orders
            WHERE created_at >= DATE('now', '-7 days')
            GROUP BY DATE(created_at)
            ORDER BY date DESC
        ''').fetchall()
        
        # Produk terlaris
        top_products = conn.execute('''
            SELECT product_name, SUM(quantity) as total_sold, SUM(subtotal) as total_revenue
            FROM order_items
            GROUP BY product_name
            ORDER BY total_sold DESC
            LIMIT 5
        ''').fetchall()
    
    text = "📈 *Statistik 7 Hari Terakhir*\n\n"
    
    for day in daily_orders:
        text += f"📅 {day['date']}: {day['count']} pesanan | {format_currency(day['revenue'] or 0)}\n"
    
    text += "\n*Produk Terlaris:*\n"
    for product in top_products:
        text += f"• {product['product_name']}: {product['total_sold']x} ({format_currency(product['total_revenue'])})\n"
    
    keyboard = [[
        InlineKeyboardButton("🔙 Kembali", callback_data="admin_dashboard")
    ]]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await query.edit_message_text(
        text,
        parse_mode='Markdown',
        reply_markup=reply_markup
    )

async def process_order(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Process an order"""
    query = update.callback_query
    await query.answer()
    
    if query.from_user.id != ADMIN_ID:
        return
    
    order_id = int(query.data.split('_')[2])
    
    keyboard = [
        [
            InlineKeyboardButton("✅ Proses", callback_data=f"status_{order_id}_processing"),
            InlineKeyboardButton("✅ Selesai", callback_data=f"status_{order_id}_completed")
        ],
        [
            InlineKeyboardButton("❌ Batal", callback_data=f"status_{order_id}_cancelled"),
            InlineKeyboardButton("🔙 Kembali", callback_data="admin_new_orders")
        ]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await query.edit_message_text(
        "Pilih aksi untuk pesanan ini:",
        reply_markup=reply_markup
    )

async def update_order_status(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Update order status"""
    query = update.callback_query
    await query.answer()
    
    if query.from_user.id != ADMIN_ID:
        return
    
    _, order_id, new_status = query.data.split('_')
    order_id = int(order_id)
    
    with get_db() as conn:
        # Update order status
        if new_status == 'completed':
            conn.execute('''
                UPDATE orders 
                SET order_status = ?, completed_at = CURRENT_TIMESTAMP
                WHERE id = ?
            ''', (new_status, order_id))
        else:
            conn.execute('''
                UPDATE orders SET order_status = ? WHERE id = ?
            ''', (new_status, order_id))
        
        # Get order details for notification
        order = conn.execute('''
            SELECT o.*, u.telegram_id 
            FROM orders o
            JOIN users u ON o.user_id = u.id
            WHERE o.id = ?
        ''', (order_id,)).fetchone()
    
    # Notify user
    if order and order['telegram_id']:
        status_messages = {
            'processing': 'Pesanan Anda sedang diproses',
            'completed': 'Pesanan Anda telah selesai',
            'cancelled': 'Pesanan Anda dibatalkan'
        }
        
        status_emoji = {
            'processing': '⚙️',
            'completed': '✅',
            'cancelled': '❌'
        }
        
        try:
            await context.bot.send_message(
                chat_id=order['telegram_id'],
                text=(
                    f"{status_emoji[new_status]} *Update Status Pesanan*\n\n"
                    f"Nomor Pesanan: `{order['order_number']}`\n"
                    f"Status: {status_messages[new_status]}\n\n"
                    f"Detail pesanan dapat dilihat di website."
                ),
                parse_mode='Markdown'
            )
        except:
            pass
    
    await query.edit_message_text(
        f"✅ Status pesanan berhasil diupdate menjadi {new_status}!"
    )

async def order_detail(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show order detail"""
    query = update.callback_query
    await query.answer()
    
    if query.from_user.id != ADMIN_ID:
        return
    
    order_id = int(query.data.split('_')[2])
    
    with get_db() as conn:
        order = conn.execute('''
            SELECT o.*, u.full_name, u.username, u.telegram_id
            FROM orders o
            JOIN users u ON o.user_id = u.id
            WHERE o.id = ?
        ''', (order_id,)).fetchone()
        
        items = conn.execute('''
            SELECT * FROM order_items WHERE order_id = ?
        ''', (order_id,)).fetchall()
    
    if not order:
        await query.edit_message_text("Pesanan tidak ditemukan.")
        return
    
    status_emoji = {
        'pending': '⏳',
        'paid': '💳',
        'processing': '⚙️',
        'completed': '✅',
        'cancelled': '❌'
    }.get(order['order_status'], '📦')
    
    text = (
        f"{status_emoji} *Detail Pesanan*\n\n"
        f"Nomor: `{order['order_number']}`\n"
        f"Status: {order['order_status'].upper()}\n"
        f"Tanggal: {order['created_at']}\n\n"
        f"👤 *Customer:*\n"
        f"Nama: {order['full_name']}\n"
        f"Username: @{order['username']}\n"
        f"Telegram ID: {order['telegram_id']}\n"
        f"WA: {order['customer_phone']}\n"
        f"Email: {order['customer_email'] or '-'}\n\n"
        f"📦 *Items:*\n"
    )
    
    for item in items:
        text += f"• {item['product_name']} x{item['quantity']} = {format_currency(item['subtotal'])}\n"
    
    text += f"\n💰 *Total: {format_currency(order['total_amount'])}*\n"
    
    if order['notes']:
        text += f"\n📝 Catatan: {order['notes']}\n"
    
    keyboard = [[
        InlineKeyboardButton("🔙 Kembali", callback_data="admin_dashboard")
    ]]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await query.edit_message_text(
        text,
        parse_mode='Markdown',
        reply_markup=reply_markup
    )

async def notify_new_order(application, order_data):
    """Function to send notification to admin when new order created"""
    if not ADMIN_ID:
        return
    
    status_emoji = {
        'pending': '⏳',
        'paid': '💳',
        'processing': '⚙️',
        'completed': '✅',
        'cancelled': '❌'
    }.get(order_data['order_status'], '📦')
    
    text = (
        f"🔔 *Pesanan Baru!*\n\n"
        f"{status_emoji} Nomor: `{order_data['order_number']}`\n"
        f"👤 Customer: {order_data['customer_name']}\n"
        f"📞 WA: {order_data['customer_phone']}\n"
        f"💰 Total: {format_currency(order_data['total_amount'])}\n"
        f"📦 Items: {order_data['item_count']} produk\n\n"
        f"Klik di bawah untuk proses:"
    )
    
    keyboard = [[
        InlineKeyboardButton(
            "✅ Proses Pesanan", 
            callback_data=f"process_order_{order_data['order_id']}"
        )
    ]]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    try:
        await application.bot.send_message(
            chat_id=ADMIN_ID,
            text=text,
            parse_mode='Markdown',
            reply_markup=reply_markup
        )
    except Exception as e:
        logger.error(f"Failed to send notification: {e}")

def main():
    """Main function to run the bot"""
    # Create application
    application = Application.builder().token(BOT_TOKEN).build()
    
    # Add handlers
    application.add_handler(CommandHandler("start", start))
    application.add_handler(CallbackQueryHandler(admin_dashboard, pattern="^admin_dashboard$"))
    application.add_handler(CallbackQueryHandler(admin_new_orders, pattern="^admin_new_orders$"))
    application.add_handler(CallbackQueryHandler(admin_all_orders, pattern="^admin_all_orders$"))
    application.add_handler(CallbackQueryHandler(admin_completed_orders, pattern="^admin_completed_orders$"))
    application.add_handler(CallbackQueryHandler(admin_stats, pattern="^admin_stats$"))
    application.add_handler(CallbackQueryHandler(process_order, pattern="^process_order_"))
    application.add_handler(CallbackQueryHandler(update_order_status, pattern="^status_"))
    application.add_handler(CallbackQueryHandler(order_detail, pattern="^detail_order_"))
    
    # Store application instance for notifications
    application.bot_data['app'] = application
    
    # Start bot
    print("🤖 Bot Telegram started...")
    application.run_polling(allowed_updates=Update.ALL_TYPES)

if __name__ == '__main__':
    main()