class SmartSnake {
    constructor() {
        this.canvas = document.getElementById('gameCanvas');
        this.ctx = this.canvas.getContext('2d');
        this.scoreElement = document.getElementById('score');
        this.foodCountElement = document.getElementById('foodCount');
        
        // Game constants
        this.gridSize = 20;
        this.tileCount = this.canvas.width / this.gridSize;
        
        // Initial snake position
        this.snake = [
            {x: 10, y: 10},
            {x: 9, y: 10},
            {x: 8, y: 10}
        ];
        
        // Game state
        this.food = {x: 15, y: 10};
        this.dx = 1;
        this.dy = 0;
        this.score = 0;
        this.foodEaten = 0;
        this.gameRunning = false;
        this.gamePaused = false;
        this.gameLoop = null;
        
        // Movement control
        this.moveInterval = 150;
        this.lastMoveTime = 0;
        
        // Simple but effective strategy
        this.noPathCount = 0;
        this.lastHeadPositions = [];
        
        // Bind methods
        this.start = this.start.bind(this);
        this.pause = this.pause.bind(this);
        this.reset = this.reset.bind(this);
        this.gameStep = this.gameStep.bind(this);
        
        this.initButtons();
        this.generateFood();
        this.draw();
    }
    
    initButtons() {
        document.getElementById('startBtn').addEventListener('click', this.start);
        document.getElementById('pauseBtn').addEventListener('click', this.pause);
        document.getElementById('resetBtn').addEventListener('click', this.reset);
    }
    
    start() {
        if (!this.gameRunning) {
            this.gameRunning = true;
            this.gamePaused = false;
            document.getElementById('startBtn').disabled = true;
            document.getElementById('pauseBtn').disabled = false;
            this.lastMoveTime = performance.now();
            this.gameLoop = requestAnimationFrame(this.gameStep);
        }
    }
    
    pause() {
        if (this.gameRunning) {
            this.gamePaused = !this.gamePaused;
            document.getElementById('pauseBtn').textContent = this.gamePaused ? 'Lanjut' : 'Jeda';
            if (!this.gamePaused) {
                this.lastMoveTime = performance.now();
                this.gameLoop = requestAnimationFrame(this.gameStep);
            }
        }
    }
    
    reset() {
        this.gameRunning = false;
        this.gamePaused = false;
        if (this.gameLoop) {
            cancelAnimationFrame(this.gameLoop);
        }
        
        this.snake = [
            {x: 10, y: 10},
            {x: 9, y: 10},
            {x: 8, y: 10}
        ];
        
        this.dx = 1;
        this.dy = 0;
        this.score = 0;
        this.foodEaten = 0;
        this.noPathCount = 0;
        this.lastHeadPositions = [];
        this.updateScore();
        
        this.generateFood();
        
        document.getElementById('startBtn').disabled = false;
        document.getElementById('pauseBtn').disabled = true;
        document.getElementById('pauseBtn').textContent = 'Jeda';
        
        this.draw();
    }
    
    gameStep(currentTime) {
        if (!this.gameRunning || this.gamePaused) return;
        
        if (currentTime - this.lastMoveTime >= this.moveInterval) {
            this.move();
            this.lastMoveTime = currentTime;
        }
        
        this.gameLoop = requestAnimationFrame(this.gameStep);
    }
    
    move() {
        const head = this.snake[0];
        
        // Simpan posisi kepala untuk deteksi stuck
        this.lastHeadPositions.push({x: head.x, y: head.y});
        if (this.lastHeadPositions.length > 10) {
            this.lastHeadPositions.shift();
        }
        
        // Cek apakah ada jalan ke makanan
        const hasPathToFood = this.hasPathToFood(head);
        
        let nextDirection = null;
        
        if (hasPathToFood) {
            // Jika ada jalan, ambil arah terbaik menuju makanan
            nextDirection = this.getBestDirectionTowardsFood(head);
            this.noPathCount = 0;
        } else {
            // Jika tidak ada jalan, hitung stuck counter
            this.noPathCount++;
            
            if (this.noPathCount > 5) {
                // Jika stuck, ikuti ekor
                nextDirection = this.followTailSafe(head);
            } else {
                // Jika baru beberapa langkah tidak ada jalan, coba bergerak ke area luas
                nextDirection = this.getDirectionToOpenSpace(head);
            }
        }
        
        // Fallback jika tidak ada direction
        if (!nextDirection) {
            nextDirection = this.getAnySafeMove(head);
        }
        
        if (nextDirection) {
            this.dx = nextDirection.dx;
            this.dy = nextDirection.dy;
        }
        
        // Hitung posisi baru
        const newHead = {
            x: head.x + this.dx,
            y: head.y + this.dy
        };
        
        // Validasi keamanan dengan prediksi ekor
        if (!this.isMoveSafeWithTail(head, this.dx, this.dy)) {
            // Cari move alternatif yang aman
            const safeMove = this.getAnySafeMove(head);
            if (safeMove) {
                newHead.x = head.x + safeMove.dx;
                newHead.y = head.y + safeMove.dy;
                this.dx = safeMove.dx;
                this.dy = safeMove.dy;
            } else {
                this.gameOver();
                return;
            }
        }
        
        // Cek apakah makan apel
        const foodEaten = (newHead.x === this.food.x && newHead.y === this.food.y);
        
        // Tambah kepala baru
        this.snake.unshift(newHead);
        
        // Hapus ekor jika tidak makan
        if (!foodEaten) {
            this.snake.pop();
        } else {
            this.score += 10;
            this.foodEaten++;
            this.updateScore();
            this.generateFood();
            this.noPathCount = 0;
            this.lastHeadPositions = [];
        }
        
        this.draw();
    }
    
    // ==================== PREDIKSI JALAN KE MAKANAN ====================
    
    hasPathToFood(head) {
        // BFS sederhana untuk cek apakah ada jalan ke makanan
        const queue = [head];
        const visited = new Set();
        visited.add(`${head.x},${head.y}`);
        
        while (queue.length > 0) {
            const current = queue.shift();
            
            // Jika sampai di makanan
            if (current.x === this.food.x && current.y === this.food.y) {
                return true;
            }
            
            // Cek tetangga
            const neighbors = [
                {x: current.x + 1, y: current.y},
                {x: current.x - 1, y: current.y},
                {x: current.x, y: current.y + 1},
                {x: current.x, y: current.y - 1}
            ];
            
            for (const neighbor of neighbors) {
                const key = `${neighbor.x},${neighbor.y}`;
                
                // Skip if out of bounds
                if (neighbor.x < 0 || neighbor.x >= this.tileCount || 
                    neighbor.y < 0 || neighbor.y >= this.tileCount) {
                    continue;
                }
                
                // Skip if visited
                if (visited.has(key)) continue;
                
                // Skip if it's snake body (except tail, because tail will move)
                let isBody = false;
                for (let i = 0; i < this.snake.length - 1; i++) {
                    if (this.snake[i].x === neighbor.x && this.snake[i].y === neighbor.y) {
                        isBody = true;
                        break;
                    }
                }
                
                if (!isBody) {
                    visited.add(key);
                    queue.push(neighbor);
                }
            }
        }
        
        return false;
    }
    
    // ==================== SAFE MOVE DENGAN PREDIKSI EKOR ====================
    
    isMoveSafeWithTail(head, dx, dy) {
        const newX = head.x + dx;
        const newY = head.y + dy;
        
        // Cek wall
        if (newX < 0 || newX >= this.tileCount || newY < 0 || newY >= this.tileCount) {
            return false;
        }
        
        // Ekor akan bergerak di langkah ini, jadi posisi ekor saat ini akan kosong
        const tail = this.snake[this.snake.length - 1];
        
        // Cek tabrakan dengan tubuh (kecuali ekor)
        for (let i = 0; i < this.snake.length - 1; i++) {
            if (this.snake[i].x === newX && this.snake[i].y === newY) {
                return false;
            }
        }
        
        // Jika newX,newY adalah posisi ekor, itu AMAN karena ekor akan bergerak
        // (tapi hanya jika kita tidak sedang makan, karena jika makan ekor tidak bergerak)
        const willEatFood = (newX === this.food.x && newY === this.food.y);
        
        if (newX === tail.x && newY === tail.y && !willEatFood) {
            // AMAN - kita bisa bergerak ke posisi ekor
            return true;
        }
        
        return true;
    }
    
    getBestDirectionTowardsFood(head) {
        const directions = [
            {dx: 1, dy: 0, weight: 0},
            {dx: -1, dy: 0, weight: 0},
            {dx: 0, dy: 1, weight: 0},
            {dx: 0, dy: -1, weight: 0}
        ];
        
        // Hitung jarak ke makanan untuk setiap arah yang aman
        for (const dir of directions) {
            const newX = head.x + dir.dx;
            const newY = head.y + dir.dy;
            
            if (!this.isMoveSafeWithTail(head, dir.dx, dir.dy)) {
                dir.weight = -1000; // Tidak aman
                continue;
            }
            
            // Jarak Manhattan ke makanan
            const distance = Math.abs(newX - this.food.x) + Math.abs(newY - this.food.y);
            dir.weight = 100 - distance; // Semakin dekat semakin besar weight
        }
        
        // Pilih arah dengan weight tertinggi
        directions.sort((a, b) => b.weight - a.weight);
        
        if (directions[0].weight > -1000) {
            return {dx: directions[0].dx, dy: directions[0].dy};
        }
        
        return null;
    }
    
    followTailSafe(head) {
        // Ikuti ekor dengan aman
        const tail = this.snake[this.snake.length - 1];
        
        // Hitung arah ke ekor
        const dx = tail.x - head.x;
        const dy = tail.y - head.y;
        
        // Coba arah langsung ke ekor
        if (Math.abs(dx) > 0) {
            const moveX = {dx: Math.sign(dx), dy: 0};
            if (this.isMoveSafeWithTail(head, moveX.dx, moveX.dy)) {
                return moveX;
            }
        }
        
        if (Math.abs(dy) > 0) {
            const moveY = {dx: 0, dy: Math.sign(dy)};
            if (this.isMoveSafeWithTail(head, moveY.dx, moveY.dy)) {
                return moveY;
            }
        }
        
        // Jika tidak bisa langsung, coba semua arah yang aman
        return this.getAnySafeMove(head);
    }
    
    getDirectionToOpenSpace(head) {
        const directions = [
            {dx: 1, dy: 0},
            {dx: -1, dy: 0},
            {dx: 0, dy: 1},
            {dx: 0, dy: -1}
        ];
        
        let bestMove = null;
        let bestSpace = -1;
        
        for (const dir of directions) {
            if (!this.isMoveSafeWithTail(head, dir.dx, dir.dy)) continue;
            
            const newX = head.x + dir.dx;
            const newY = head.y + dir.dy;
            const space = this.calculateOpenSpace({x: newX, y: newY});
            
            if (space > bestSpace) {
                bestSpace = space;
                bestMove = dir;
            }
        }
        
        return bestMove;
    }
    
    calculateOpenSpace(pos) {
        // Flood fill sederhana untuk menghitung ruang terbuka
        const visited = new Set();
        const queue = [pos];
        visited.add(`${pos.x},${pos.y}`);
        
        let space = 0;
        const maxSpace = 15; // Batasi untuk performance
        
        while (queue.length > 0 && space < maxSpace) {
            const current = queue.shift();
            space++;
            
            const neighbors = [
                {x: current.x + 1, y: current.y},
                {x: current.x - 1, y: current.y},
                {x: current.x, y: current.y + 1},
                {x: current.x, y: current.y - 1}
            ];
            
            for (const neighbor of neighbors) {
                const key = `${neighbor.x},${neighbor.y}`;
                
                // Cek wall
                if (neighbor.x < 0 || neighbor.x >= this.tileCount || 
                    neighbor.y < 0 || neighbor.y >= this.tileCount) {
                    continue;
                }
                
                // Cek sudah dikunjungi
                if (visited.has(key)) continue;
                
                // Cek apakah itu tubuh (kecuali ekor)
                let isBody = false;
                for (let i = 0; i < this.snake.length - 1; i++) {
                    if (this.snake[i].x === neighbor.x && this.snake[i].y === neighbor.y) {
                        isBody = true;
                        break;
                    }
                }
                
                if (!isBody) {
                    visited.add(key);
                    queue.push(neighbor);
                }
            }
        }
        
        return space;
    }
    
    getAnySafeMove(head) {
        const directions = [
            {dx: 1, dy: 0},
            {dx: -1, dy: 0},
            {dx: 0, dy: 1},
            {dx: 0, dy: -1}
        ];
        
        // Acak urutan untuk variasi
        for (let i = directions.length - 1; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            [directions[i], directions[j]] = [directions[j], directions[i]];
        }
        
        for (const dir of directions) {
            if (this.isMoveSafeWithTail(head, dir.dx, dir.dy)) {
                return dir;
            }
        }
        
        return null;
    }
    
    // ==================== GAME UTILITIES ====================
    
    generateFood() {
        let newFood;
        let attempts = 0;
        const maxAttempts = 1000;
        
        do {
            newFood = {
                x: Math.floor(Math.random() * this.tileCount),
                y: Math.floor(Math.random() * this.tileCount)
            };
            attempts++;
            
            const foodOnSnake = this.snake.some(segment => 
                segment.x === newFood.x && segment.y === newFood.y
            );
            
            if (!foodOnSnake) {
                this.food = newFood;
                return;
            }
        } while (attempts < maxAttempts);
        
        // Cari sel kosong
        for (let y = 0; y < this.tileCount; y++) {
            for (let x = 0; x < this.tileCount; x++) {
                const isSnakeCell = this.snake.some(segment => segment.x === x && segment.y === y);
                if (!isSnakeCell) {
                    this.food = {x, y};
                    return;
                }
            }
        }
        
        this.gameOver();
    }
    
    gameOver() {
        this.gameRunning = false;
        this.gamePaused = false;
        if (this.gameLoop) {
            cancelAnimationFrame(this.gameLoop);
        }
        
        document.getElementById('startBtn').disabled = false;
        document.getElementById('pauseBtn').disabled = true;
        document.getElementById('pauseBtn').textContent = 'Jeda';
        
        this.ctx.fillStyle = 'rgba(0, 0, 0, 0.7)';
        this.ctx.fillRect(0, 0, this.canvas.width, this.canvas.height);
        this.ctx.fillStyle = 'white';
        this.ctx.font = '20px Arial';
        this.ctx.textAlign = 'center';
        this.ctx.fillText('Game Over!', this.canvas.width / 2, this.canvas.height / 2);
        this.ctx.font = '16px Arial';
        this.ctx.fillText(`Skor: ${this.score}`, this.canvas.width / 2, this.canvas.height / 2 + 30);
    }
    
    updateScore() {
        this.scoreElement.textContent = this.score;
        this.foodCountElement.textContent = this.foodEaten;
    }
    
    draw() {
        // Clear canvas
        this.ctx.fillStyle = '#111';
        this.ctx.fillRect(0, 0, this.canvas.width, this.canvas.height);
        
        // Draw grid
        this.ctx.strokeStyle = '#222';
        this.ctx.lineWidth = 0.5;
        for (let i = 0; i <= this.tileCount; i++) {
            this.ctx.beginPath();
            this.ctx.moveTo(i * this.gridSize, 0);
            this.ctx.lineTo(i * this.gridSize, this.canvas.height);
            this.ctx.stroke();
            
            this.ctx.beginPath();
            this.ctx.moveTo(0, i * this.gridSize);
            this.ctx.lineTo(this.canvas.width, i * this.gridSize);
            this.ctx.stroke();
        }
        
        // Draw food
        const pulseScale = 1 + Math.sin(Date.now() * 0.01) * 0.1;
        this.ctx.fillStyle = '#ff4444';
        this.ctx.shadowColor = '#ff0000';
        this.ctx.shadowBlur = 15;
        this.ctx.beginPath();
        this.ctx.arc(
            this.food.x * this.gridSize + this.gridSize / 2,
            this.food.y * this.gridSize + this.gridSize / 2,
            (this.gridSize / 2 - 2) * pulseScale,
            0,
            Math.PI * 2
        );
        this.ctx.fill();
        
        // Draw info
        this.ctx.fillStyle = 'white';
        this.ctx.font = '12px Arial';
        this.ctx.fillText(`No Path: ${this.noPathCount}`, 10, 20);
        
        // Draw snake
        this.snake.forEach((segment, index) => {
            const gradient = this.ctx.createRadialGradient(
                segment.x * this.gridSize + this.gridSize / 2,
                segment.y * this.gridSize + this.gridSize / 2,
                0,
                segment.x * this.gridSize + this.gridSize / 2,
                segment.y * this.gridSize + this.gridSize / 2,
                this.gridSize
            );
            
            if (index === 0) {
                gradient.addColorStop(0, '#4CAF50');
                gradient.addColorStop(1, '#2E7D32');
            } else {
                const brightness = 1 - (index / this.snake.length) * 0.5;
                gradient.addColorStop(0, `rgba(76, 175, 80, ${brightness})`);
                gradient.addColorStop(1, `rgba(46, 125, 50, ${brightness})`);
            }
            
            this.ctx.fillStyle = gradient;
            this.ctx.shadowColor = index === 0 ? '#00ff00' : '#006400';
            this.ctx.shadowBlur = index === 0 ? 10 : 5;
            this.ctx.fillRect(
                segment.x * this.gridSize + 1,
                segment.y * this.gridSize + 1,
                this.gridSize - 2,
                this.gridSize - 2
            );
            
            // Draw eyes on head
            if (index === 0) {
                this.ctx.fillStyle = 'white';
                this.ctx.shadowBlur = 0;
                
                // Left eye
                this.ctx.beginPath();
                this.ctx.arc(
                    segment.x * this.gridSize + this.gridSize / 3,
                    segment.y * this.gridSize + this.gridSize / 3,
                    2,
                    0,
                    Math.PI * 2
                );
                this.ctx.fill();
                
                // Right eye
                this.ctx.beginPath();
                this.ctx.arc(
                    segment.x * this.gridSize + (this.gridSize * 2) / 3,
                    segment.y * this.gridSize + this.gridSize / 3,
                    2,
                    0,
                    Math.PI * 2
                );
                this.ctx.fill();
                
                // Pupils
                const dx = this.food.x - segment.x;
                const dy = this.food.y - segment.y;
                const angle = Math.atan2(dy, dx);
                
                this.ctx.fillStyle = 'black';
                this.ctx.beginPath();
                this.ctx.arc(
                    segment.x * this.gridSize + this.gridSize / 3 + Math.cos(angle) * 1.5,
                    segment.y * this.gridSize + this.gridSize / 3 + Math.sin(angle) * 1.5,
                    1,
                    0,
                    Math.PI * 2
                );
                this.ctx.fill();
                
                this.ctx.beginPath();
                this.ctx.arc(
                    segment.x * this.gridSize + (this.gridSize * 2) / 3 + Math.cos(angle) * 1.5,
                    segment.y * this.gridSize + this.gridSize / 3 + Math.sin(angle) * 1.5,
                    1,
                    0,
                    Math.PI * 2
                );
                this.ctx.fill();
            }
        });
        
        // Draw tail indicator (untuk debugging)
        const tail = this.snake[this.snake.length - 1];
        this.ctx.fillStyle = 'rgba(255, 255, 0, 0.3)';
        this.ctx.beginPath();
        this.ctx.arc(
            tail.x * this.gridSize + this.gridSize / 2,
            tail.y * this.gridSize + this.gridSize / 2,
            this.gridSize / 3,
            0,
            Math.PI * 2
        );
        this.ctx.fill();
        
        this.ctx.shadowBlur = 0;
    }
}

document.addEventListener('DOMContentLoaded', () => {
    new SmartSnake();
});